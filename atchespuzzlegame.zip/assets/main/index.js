window.__require = function t(e, o, n) {
function i(c, r) {
if (!o[c]) {
if (!e[c]) {
var a = c.split("/");
a = a[a.length - 1];
if (!e[a]) {
var l = "function" == typeof __require && __require;
if (!r && l) return l(a, !0);
if (s) return s(a, !0);
throw new Error("Cannot find module '" + c + "'");
}
c = a;
}
var u = o[c] = {
exports: {}
};
e[c][0].call(u.exports, function(t) {
return i(e[c][1][t] || t);
}, u, u.exports, t, e, o, n);
}
return o[c].exports;
}
for (var s = "function" == typeof __require && __require, c = 0; c < n.length; c++) i(n[c]);
return i;
}({
GG: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "83c58kaN51CzqJTmSOaeN7b", "GG");
var n, i = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, n) {
var i, s = arguments.length, c = s < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (c = (s < 3 ? i(c) : s > 3 ? i(e, o, c) : i(e, o)) || c);
return s > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, r = c.ccclass, a = c.property, l = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.logs = null;
e.text = "hello";
return e;
}
e.prototype.onTestNativeAPI = function() {
console.log("fzgui.PlatformInterface.deviceID====>" + fzgui.PlatformInterface.deviceID);
};
e.prototype.onFacebook = function() {
console.log("======================>onFacebook===");
if (cc.sys.os == cc.sys.OS_ANDROID || cc.sys.os == cc.sys.OS_IOS) {
console.log("======================>onFacebook===1");
console.log(sdkbox);
console.log(sdkbox.PluginFacebook);
console.log("======================>onFacebook===2");
if ("undefined" == typeof sdkbox) {
this.log("sdkbox is undefined");
return;
}
if ("undefined" == typeof sdkbox.PluginFacebook) {
this.log("sdkbox.PluginFacebook is undefined");
return;
}
sdkbox.PluginFacebook.setListener({
onLogin: function(t, e) {
console.log("======================>onLogin===2" + JSON.stringify(e));
console.log("======================>isLogin===2" + t);
if (t) {
console.log("sdkbox.PluginFacebook.getAccessToken()" + sdkbox.PluginFacebook.getAccessToken());
var o = sdkbox.PluginFacebook.getAccessToken(), n = sdkbox.PluginFacebook.getUserID();
console.log("DAY LA TOKEN FACEBOOK");
console.log(o);
console.log(n);
}
},
onAPI: function() {},
onSharedSuccess: function() {},
onSharedFailed: function() {},
onSharedCancel: function() {},
onPermission: function() {}
});
sdkbox.PluginFacebook.init();
sdkbox.PluginFacebook.login([ "public_profile" ]);
}
};
e.prototype.onLoad = function() {
this.initPlugin();
};
e.prototype.initPlugin = function() {
this.initPluginFacebook();
};
e.prototype.initPluginFacebook = function() {
if ("undefined" != typeof sdkbox) if ("undefined" != typeof sdkbox.PluginFacebook) {
var t = this;
sdkbox.PluginFacebook.setListener({
onLogin: function(e) {
e ? t.log("login successful") : t.log("login failed");
},
onAPI: function(e, o) {
t.log("onAPI t:" + e);
if ("me" == e) {
var n = JSON.parse(o);
t.log("onAPI Name:" + n.name);
}
},
onSharedSuccess: function() {
t.log("share successful");
},
onSharedFailed: function() {
t.log("share failed");
},
onSharedCancel: function() {
t.log("share canceled");
},
onPermission: function(e) {
e ? t.log("request permission successful") : t.log("request permission failed");
},
onRequestInvitableFriends: function(e) {
t.log(JSON.stringify(e));
},
onInviteFriendsWithInviteIdsResult: function(e, o) {
t.log("onInviteFriendsWithInviteIdsResult result=" + (e ? "ok" : "error") + " " + o);
},
onInviteFriendsResult: function(e, o) {
t.log("onInviteFriendsResult result=" + (e ? "ok" : "error") + " " + o);
}
});
sdkbox.PluginFacebook.init();
} else this.log("sdkbox.PluginFacebook is undefined"); else this.log("sdkbox is undefined");
};
e.prototype.onButton1 = function() {
if (sdkbox.PluginFacebook.isLoggedIn()) {
this.log("FB to Logout");
sdkbox.PluginFacebook.logout();
} else {
this.log("FB to Login");
sdkbox.PluginFacebook.login([ "public_profile" ]);
}
};
e.prototype.onButton2 = function() {
var t = sdkbox.PluginFacebook.getPermissionList();
this.log("FB permission:" + t);
cc.log("FB token:" + sdkbox.PluginFacebook.getAccessToken());
this.log("FB UserID:" + sdkbox.PluginFacebook.getUserID());
this.log("FB SDK Ver:" + sdkbox.PluginFacebook.getSDKVersion());
sdkbox.PluginFacebook.api("me", "GET", [ "first_name" ], "me");
};
e.prototype.log = function(t) {
cc.log(t);
for (var e = this.logs.string.split("\n"); e.length > 5; ) e.shift();
e.push(t);
this.logs.string = e.join("\n");
};
s([ a(cc.Label) ], e.prototype, "logs", void 0);
s([ a ], e.prototype, "text", void 0);
return s([ r ], e);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ],
HotUpdateFirstGame: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "e94d0FNb95GWJEjpIGLpM8Y", "HotUpdateFirstGame");
var n, i = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, n) {
var i, s = arguments.length, c = s < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (c = (s < 3 ? i(c) : s > 3 ? i(e, o, c) : i(e, o)) || c);
return s > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("../Zrequire/LoadingGameZ"), r = cc._decorator, a = r.ccclass, l = r.property, u = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.versionLabel = null;
e.lbMsg = null;
e.versionFirst = "1.0.0";
e.prgBar = null;
e.btnAccept = null;
e._countClearCache = 0;
e._updating = !1;
e._canRetry = !1;
e._failCount = 0;
e._storagePath = "";
e._am = null;
e.versionCompareHandle = null;
e._customManifestStr = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.ERROR_DOMAIN_ZERO = 5;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
console.log(" ======LoadingGameZ.CONFIG_FIRST_GAME.mf======" + c.LoadingGameZ.CONFIG_FIRST_GAME.mf);
if (cc.sys.isNative) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + c.LoadingGameZ.CONFIG_FIRST_GAME.p;
console.log("======================>onFacebook===1");
this.versionCompareHandle = function(t, e) {
var o = t.split("."), n = e.split(".");
console.log("HOT UPDATE: JS Custom Version Compare: version A is " + o + ", version B is " + n);
cc.sys.localStorage.setItem("HotUpdateShowVersion_SS", JSON.stringify(t));
cc.director.emit("HotUpdateShowVersion", t);
for (var i = 0; i < o.length; ++i) {
var s = parseInt(o[i]), c = parseInt(n[i] || 0);
if (s !== c) return s - c;
}
return n.length > o.length ? -1 : 0;
};
this._am = new jsb.AssetsManager(this._customManifestStr, this._storagePath, this.versionCompareHandle);
console.log(this._am._tempVersionPath);
this._am.setVerifyCallback(function(t, e) {
var o = jsb.fileUtils.getDataFromFile(t);
window.md5(o) == e.md5 || console.log("md5 is wrong, file:" + t);
return !0;
});
cc.sys.os, cc.sys.OS_ANDROID, this._am.setMaxConcurrentTask(2);
this.checkUpdate();
} else this.runOnWeb();
};
e.prototype._updateLabelVersion = function() {
this.versionLabel && (this.versionLabel.string = "v:" + this._am.getLocalManifest().getVersion());
};
e.prototype.runOnWeb = function() {
this.onUpdateFinish();
};
e.prototype.onDestroy = function() {
this._am && this._am.setEventCallback(null);
this._am = null;
};
e.prototype.showLog = function(t) {
console.log("[HotUpdate===-------\x3eMAIN][showLog]----" + t);
this.lbMsg.string = t;
};
e.prototype.retry = function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
this.showLog("Tải lại tệp lỗi...");
this._am.downloadFailedAssets();
}
};
e.prototype.updateCallback = function(t) {
var e = !1, o = !1;
console.log("event.getEventCode() ====" + JSON.stringify(t.getEventCode()));
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.errorCase = this.ERROR_DOWNLOAD;
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var n = t.getPercent();
if (isNaN(n)) return;
var i = t.getMessage();
this.disPatchRateEvent(n, i);
this.showLog("Loading: " + Math.floor(100 * n) + "%");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải xuống được manifest");
this.errorCase = this.ERROR_DOWNLOAD;
o = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất.");
this.prgBar.progress = 1;
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.showLog("Kết thúc cập nhật." + t.getMessage());
this.disPatchRateEvent(1);
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.showLog("Cập nhật lỗi." + t.getMessage());
this._updating = !1;
this._canRetry = !0;
this._failCount++;
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.showLog("Lỗi khi cập nhật");
console.log("Lỗi khi cập nhật: " + t.getAssetId() + ", " + t.getMessage());
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.showLog("Lỗi giải nén");
this.errorCase = this.ERROR_DOWNLOAD;
}
if (o) {
this._am.setEventCallback(null);
this._updating = !1;
}
if (this._canRetry) {
this.showLog("Kết nối không ổn định, đồng ý để tải lại hoặc xoá rồi cài lại");
this.btnAccept.node.active = !0;
} else this.btnAccept.node.active = o;
if (e) {
this._am.setEventCallback(null);
var s = jsb.fileUtils.getSearchPaths(), c = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(s, c);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(s));
jsb.fileUtils.setSearchPaths(s);
console.log("path game main ==========================" + jsb.fileUtils.getWritablePath());
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 100);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCallback.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest(this._customManifestStr, this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.checkCallback = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải được manifest，Skip");
this.hotUpdateFinish(!1);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.showLog("Có một phiên bản mới và cần được cập nhật");
this._updating = !1;
this.hotUpdate();
return;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var e = t.getPercent();
if (isNaN(e)) return;
var o = t.getMessage();
this.showLog("Loading: " + e + ", msg: " + o);
return;

default:
console.log("event.getEventCode():" + t.getEventCode());
return;
}
this._am.setEventCallback(null);
this._updating = !1;
};
e.prototype.checkUpdate = function() {
if (this._updating) this.showLog("Kiểm tra các bản cập nhật..."); else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
console.log(" ======LoadingGameZ.CONFIG_FIRST_GAME.mf======" + c.LoadingGameZ.CONFIG_FIRST_GAME.mf);
var t = c.LoadingGameZ.CONFIG_FIRST_GAME.mf;
this._customManifestStr = JSON.stringify({
packageUrl: t,
remoteManifestUrl: t + "project.manifest",
remoteVersionUrl: t + "version.manifest",
version: this.versionFirst,
assets: {},
searchPaths: []
});
console.log(this._customManifestStr);
var e = new jsb.Manifest(this._customManifestStr, this._storagePath);
cc.assetManager.md5Pipe && (e = cc.assetManager.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e, this._storagePath);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCallback.bind(this));
this._am.checkUpdate();
this._updating = !0;
this.disPatchRateEvent(.01);
} else {
this.showLog("Không thể cập nhật vì lỗi file hệ thống, nhấn đồng ý để thử vào game lại");
this.errorCase = this.ERROR_CHECK_DOWNLOAD;
this.btnAccept.node.active = !0;
}
}
};
e.prototype.hotUpdateFinish = function(t) {
t ? cc.director.emit("HotUpdateFinish", t) : this.btnAccept.node.active = !0;
};
e.prototype.disPatchRateEvent = function(t, e) {
void 0 === e && (e = "");
t > 1 && (t = 1);
cc.director.emit("HotUpdateRate", t);
};
e.prototype.checkVersion = function() {
this.checkUpdate();
this.lbMsg.string = "Đang kiểm tra các bản cập nhật, vui lòng đợi";
};
e.prototype.onEnable = function() {
cc.director.on("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.on("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.on("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onDisable = function() {
cc.director.off("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.off("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.off("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onHotUpdateRate = function(t) {
var e = t;
e > 1 && (e = 1);
this.prgBar.progress = e;
this.lbMsg.string = "Cập nhật tài nguyên: " + (100 * e).toFixed(2) + "%";
};
e.prototype.onUpdateFinish = function() {
var t = this;
this.lbMsg.string = "";
cc.director.preloadScene("Game", function(e, o) {
var n = e / o;
t.lbMsg.string = "Đang tải " + n.toFixed(0) + " %";
}, function(t) {
t ? cc.error(t) : cc.director.loadScene("Game");
});
};
e.prototype.clearCache = function() {
if (this._countClearCache >= 5) {
this._countClearCache = 0;
console.log(this._countClearCache);
var t = this._storagePath;
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
}
this._countClearCache++;
};
e.prototype.onHotUpdateFinish = function() {
this.onUpdateFinish();
};
e.prototype.onClickConfirm = function() {
this.btnAccept.node.active = !1;
switch (this.errorCase) {
case this.ERROR_CHECK_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.checkUpdate();
break;

case this.ERROR_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.retry();
break;

case this.ERROR_GETINFO:
this.errorCase = this.ERROR_NO;
this.showLog("Đang kiểm tra thông tin lại");
this.checkUpdate();
break;

case this.ERROR_DOMAIN_ZERO:
this.showLog("Đang kiểm tra thông tin lại, vui lòng chờ trong giây lát");
this.checkUpdate();
}
};
s([ l(cc.Label) ], e.prototype, "versionLabel", void 0);
s([ l(cc.Label) ], e.prototype, "lbMsg", void 0);
s([ l ], e.prototype, "versionFirst", void 0);
s([ l(cc.ProgressBar) ], e.prototype, "prgBar", void 0);
s([ l(cc.Button) ], e.prototype, "btnAccept", void 0);
return s([ a ], e);
}(cc.Component);
o.default = u;
cc._RF.pop();
}, {
"../Zrequire/LoadingGameZ": "LoadingGameZ"
} ],
Https: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "0641bZfGA9DPJIaA3rIbXVE", "Https");
Object.defineProperty(o, "__esModule", {
value: !0
});
o.Https = void 0;
var n = function() {
function t() {}
t.get = function(t, e, o) {
void 0 === o && (o = !0);
var n = t, i = cc.loader.getXMLHttpRequest();
i.timeout = 5e3;
i.open("GET", n, !0);
cc.sys.isNative && i.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
o && cc.log("http request.." + n);
i.onreadystatechange = function() {
if (4 === i.readyState) if (i.status >= 200 && i.status < 300) {
var t = JSON.parse(i.responseText);
null != e && e(t);
o && cc.log("http request.." + n);
} else {
e(null);
o && cc.log("http request.." + n);
}
};
i.send();
};
t.post = function(t, e, o) {
var n = cc.loader.getXMLHttpRequest();
n.timeout = 5e3;
n.open("POST", t);
n.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
n.onreadystatechange = function() {
if (4 == n.readyState) if (n.status >= 200 && n.status < 400) {
var t = n.responseText;
o && o(n.status, t);
} else o && o(n.status, null);
};
n.send(JSON.stringify(e));
};
t.getAPI = function(t, e) {
cc.log(t);
var o = cc.loader.getXMLHttpRequest();
o.timeout = 1e3;
o.open("GET", t, !0);
cc.sys.isNative && o.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
o.onreadystatechange = function() {
if (4 === o.readyState) if (o.status >= 200 && o.status < 300) {
var t = o.responseText;
null != e && e(t);
} else e(null);
};
o.send();
};
t.getRaw = function(t, e, o) {
void 0 === o && (o = !0);
var n = cc.loader.getXMLHttpRequest();
n.timeout = 5e3;
cc.log("url:" + t);
n.open("GET", t, !0);
cc.sys.isNative && n.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
o && cc.log("http request.." + t);
n.onreadystatechange = function() {
if (4 === n.readyState) if (n.status >= 200 && n.status < 300) {
var i = JSON.parse(n.responseText);
null != e && e(i);
o && cc.log("http response.." + t);
} else {
e(null);
o && cc.log("http fail.." + t);
}
};
n.send();
};
t.getCountry = function(e) {
return new Promise(function(o) {
t.getRaw("http://ip-api.com/json", function(t) {
t && "success" == t.status && t.countryCode ? o(e && e(t.countryCode)) : o(e && e(null));
}, !1);
});
};
t.postAPI = function(t, e, o) {
var n = t;
if (0 === n.search("http://") || 0 === n.search("https://")) {
var i = new XMLHttpRequest();
i.onload = function() {
if (200 == i.status && 4 == i.readyState) {
var t = null;
try {
t = JSON.parse(i.responseText);
} catch (t) {}
o && o(t);
}
}, i.onerror = function() {
o && o(null);
}, i.timeout = 5e3, i.open("POST", n), i.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), 
i.send(e);
}
};
t.userHash = "";
t.dataPlayerInfoEgo = null;
return t;
}();
o.Https = n;
cc._RF.pop();
}, {} ],
LoadingGameZ: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "e5f902jEhxIJKnJ4KMXaL2w", "LoadingGameZ");
var n, i = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, n) {
var i, s = arguments.length, c = s < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (c = (s < 3 ? i(c) : s > 3 ? i(e, o, c) : i(e, o)) || c);
return s > 3 && c && Object.defineProperty(e, o, c), c;
}, c = this && this.__awaiter || function(t, e, o, n) {
return new (o || (o = Promise))(function(i, s) {
function c(t) {
try {
a(n.next(t));
} catch (t) {
s(t);
}
}
function r(t) {
try {
a(n.throw(t));
} catch (t) {
s(t);
}
}
function a(t) {
t.done ? i(t.value) : (e = t.value, e instanceof o ? e : new o(function(t) {
t(e);
})).then(c, r);
var e;
}
a((n = n.apply(t, e || [])).next());
});
}, r = this && this.__generator || function(t, e) {
var o, n, i, s, c = {
label: 0,
sent: function() {
if (1 & i[0]) throw i[1];
return i[1];
},
trys: [],
ops: []
};
return s = {
next: r(0),
throw: r(1),
return: r(2)
}, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
return this;
}), s;
function r(t) {
return function(e) {
return a([ t, e ]);
};
}
function a(s) {
if (o) throw new TypeError("Generator is already executing.");
for (;c; ) try {
if (o = 1, n && (i = 2 & s[0] ? n.return : s[0] ? n.throw || ((i = n.return) && i.call(n), 
0) : n.next) && !(i = i.call(n, s[1])).done) return i;
(n = 0, i) && (s = [ 2 & s[0], i.value ]);
switch (s[0]) {
case 0:
case 1:
i = s;
break;

case 4:
c.label++;
return {
value: s[1],
done: !1
};

case 5:
c.label++;
n = s[1];
s = [ 0 ];
continue;

case 7:
s = c.ops.pop();
c.trys.pop();
continue;

default:
if (!(i = c.trys, i = i.length > 0 && i[i.length - 1]) && (6 === s[0] || 2 === s[0])) {
c = 0;
continue;
}
if (3 === s[0] && (!i || s[1] > i[0] && s[1] < i[3])) {
c.label = s[1];
break;
}
if (6 === s[0] && c.label < i[1]) {
c.label = i[1];
i = s;
break;
}
if (i && c.label < i[2]) {
c.label = i[2];
c.ops.push(s);
break;
}
i[2] && c.ops.pop();
c.trys.pop();
continue;
}
s = e.call(t, c);
} catch (t) {
s = [ 6, t ];
n = 0;
} finally {
o = i = 0;
}
if (5 & s[0]) throw s[1];
return {
value: s[0] ? s[1] : void 0,
done: !0
};
}
};
Object.defineProperty(o, "__esModule", {
value: !0
});
o.LoadingGameZ = o.apiAhihii = void 0;
var a = t("./Https");
o.apiAhihii = {
g: "",
mf: "",
p: ""
};
var l = cc._decorator, u = l.ccclass, p = l.property, h = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.sceneGameIOS = null;
e.SceneGameAndroid = null;
e.SceneGameMain = null;
e.packageName = "";
e.listDMBK = [];
e.idxDomain = 0;
e.config = null;
return e;
}
n = e;
e.prototype.start = function() {
var t = this;
cc.log("===================start===========>");
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
var e = "https://xxx.kabuto.one/".replace("xxx", this.getBundleIdSubDomain()), o = "https://xxx.goketsu.top/".replace("xxx", this.getBundleIdSubDomain());
this.listDMBK = this.listDMBK.map(function(e) {
console.log(t.getBundleId());
return e + t.getBundleId() + ".txt";
});
this.listDMBK.push(e + this.getBundleId() + ".txt");
this.listDMBK.push(o + this.getBundleId() + ".txt");
this.getGameInfo();
};
e.prototype._checkCountry = function(t) {
return c(this, void 0, void 0, function() {
return r(this, function(e) {
switch (e.label) {
case 0:
cc.log("_checkCountry ======" + JSON.stringify(t));
return [ 4, new Promise(function(e) {
a.Https.getCountry(function(o) {
var n;
cc.log("this._listCountry ======" + JSON.stringify(t));
var i = t && t.find(function(t) {
return t.toUpperCase() == o;
});
cc.log("_checkCountry ======" + i);
n = !!(i && i.length > 0);
e(n);
});
}) ];

case 1:
return [ 2, e.sent() ];
}
});
});
};
e.prototype.shuffleWord = function(t) {
var e = "";
t = t.split("");
for (;t.length > 0; ) e += t.splice(.6 * t.length << 0, 1);
return e;
};
e.prototype.getBundleIdSubDomain = function() {
var t = "com.yolo.atchespuzzlegame".split(".").join(""), e = btoa(t);
return this.shuffleWord(e).toLowerCase().replace(/[^a-z]/gi, "");
};
e.prototype.getBundleId = function() {
var t = "com.yolo.atchespuzzlegame".split(".").join(""), e = btoa(t);
return this.shuffleWord(e).toLowerCase().replace(/[^a-z]/gi, "");
};
e.prototype.getGameInfo = function() {
var t = this;
cc.log("getGameInfo===========>");
n.CONFIG_FIRST_GAME = o.apiAhihii;
cc.sys.getNetworkType() != cc.sys.NetworkType.NONE ? this.scheduleOnce(function() {
var e = cc.sys.localStorage.getItem("KEY_DOMAIN_INFO_BACKUP" + t.packageName);
e ? t.onRequestConfig(e) : t.onRequestConfig(t.listDMBK[t.idxDomain]);
}) : this.startMinigame();
};
e.prototype.startMinigame = function() {
cc.sys.os === cc.sys.OS_IOS ? cc.director.loadScene(this.sceneGameIOS.name) : cc.director.loadScene(this.SceneGameAndroid.name);
};
e.prototype.startGameMain = function() {
cc.director.loadScene(this.SceneGameMain.name);
};
e.prototype.onRequestConfig = function(t) {
var e = this;
console.log("urll manifestttttttt ======> " + t);
var o = cc.loader.getXMLHttpRequest();
o.onreadystatechange = function() {
if (4 === o.readyState) if (200 === o.status) {
console.log("xhr.responseText ======> " + o.responseText);
o.responseText && e.onProgessZZ(o.responseText.trim());
} else cc.sys.isNative && e.onTryRequest();
};
o.onerror = function() {
console.log("==== load config loi ===");
e.onTryRequest();
};
o.ontimeout = function() {
console.log("timeout " + t);
e.startMinigame();
};
o.timeout = 3e3;
cc.sys.isNative && o.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
o.open("GET", t, !0);
o.send();
};
e.prototype.onProgessZZ = function(t) {
var e = JSON.parse(atob(t));
console.log(e);
this.config = e;
n.CONFIG_FIRST_GAME = this.config;
if (null != this.config) {
console.log(n.CONFIG_FIRST_GAME);
this.startGameMain();
} else this.startMinigame();
};
e.prototype.onTryRequest = function() {
var t = !0;
this.idxDomain++;
this.idxDomain >= this.listDMBK.length && (t = !1);
t ? this.onRequestConfig(this.listDMBK[this.idxDomain]) : this.startMinigame();
};
var n;
e.CONFIG_FIRST_GAME = null;
s([ p(cc.SceneAsset) ], e.prototype, "sceneGameIOS", void 0);
s([ p(cc.SceneAsset) ], e.prototype, "SceneGameAndroid", void 0);
s([ p(cc.SceneAsset) ], e.prototype, "SceneGameMain", void 0);
s([ p(cc.String) ], e.prototype, "packageName", void 0);
s([ p([ cc.String ]) ], e.prototype, "listDMBK", void 0);
return n = s([ u ], e);
}(cc.Component);
o.LoadingGameZ = h;
cc._RF.pop();
}, {
"./Https": "Https"
} ],
TestFacebook: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "7fcf5adHuJO2bfCL8Xvg87j", "TestFacebook");
var n, i = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, n) {
var i, s = arguments.length, c = s < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (c = (s < 3 ? i(c) : s > 3 ? i(e, o, c) : i(e, o)) || c);
return s > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, r = c.ccclass, a = c.property, l = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.label = null;
e.text = "hello";
return e;
}
e.prototype.start = function() {};
e.prototype.onFacebook = function() {
console.log("======================>onFacebook===");
if (cc.sys.os == cc.sys.OS_ANDROID || cc.sys.os == cc.sys.OS_IOS) {
console.log("======================>onFacebook===1");
sdkbox.PluginFacebook.init();
console.log("======================>onFacebook===2");
sdkbox.PluginFacebook.setListener({
onLogin: function(t) {
if (t) {
var e = sdkbox.PluginFacebook.getAccessToken(), o = sdkbox.PluginFacebook.getUserID();
console.log("DAY LA TOKEN FACEBOOK");
console.log(e);
console.log(o);
}
},
onAPI: function() {},
onSharedSuccess: function() {},
onSharedFailed: function() {},
onSharedCancel: function() {},
onPermission: function() {}
});
}
};
s([ a(cc.Label) ], e.prototype, "label", void 0);
s([ a ], e.prototype, "text", void 0);
return s([ r ], e);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ],
cc: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "c31c5sGxYRM5LGk4LpIW39a", "cc");
var n, i = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, n) {
var i, s = arguments.length, c = s < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (c = (s < 3 ? i(c) : s > 3 ? i(e, o, c) : i(e, o)) || c);
return s > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = cc._decorator, r = c.ccclass, a = c.property, l = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.isVerticle = !1;
e.sizePortrait = new cc.Size(720, 1280);
e.sizeLanscape = new cc.Size(1280, 720);
return e;
}
e.prototype.onLoad = function() {
cc.log("cc.sys.os =====: " + cc.sys.os);
cc.log("isVerticle =====: " + this.isVerticle);
cc.sys.os == cc.sys.OS_IOS ? this.isVerticle ? this.callbackV() : this.callbackH() : this.isVerticle ? this.callbackAndroidVerticle() : this.callbackAndroidHorital();
};
e.prototype.callbackH = function() {
if (cc.sys.os == cc.sys.OS_IOS) {
jsb.reflection.callStaticMethod("AppController", "setOrientation:", "H");
var t = cc.view.getFrameSize();
cc.log("frameSize: " + t.width + "   " + t.height);
cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
t.width > t.height && cc.view.setFrameSize(t.height, t.width);
cc.view.setDesignResolutionSize(this.sizeLanscape.width, this.sizeLanscape.height, cc.ResolutionPolicy.FIXED_HEIGHT);
cc.Canvas.instance.designResolution = cc.size(this.sizeLanscape.width, this.sizeLanscape.height);
}
};
e.prototype.callbackV = function() {
if (cc.sys.os == cc.sys.OS_IOS) {
cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
jsb.reflection.callStaticMethod("AppController", "setOrientation:", "V");
var t = cc.view.getFrameSize();
cc.log("màn hình dọc ios ========= " + this.sizePortrait.width + "   " + this.sizePortrait.height);
cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
t.width > t.height && cc.view.setFrameSize(t.height, t.width);
cc.view.setDesignResolutionSize(this.sizePortrait.width, this.sizePortrait.height, cc.ResolutionPolicy.FIXED_WIDTH);
cc.Canvas.instance.designResolution = cc.size(this.sizePortrait.width, this.sizePortrait.height);
window.jsb && window.dispatchEvent(new cc.Event.EventCustom("resize", !0));
}
};
e.prototype.callbackAndroidVerticle = function(t) {
void 0 === t && (t = null);
jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "setOrientation", "(Ljava/lang/String;)V", "V");
cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
cc.view.setDesignResolutionSize(this.sizePortrait.width, this.sizePortrait.height, cc.ResolutionPolicy.FIXED_WIDTH);
};
e.prototype.callbackAndroidHorital = function(t) {
void 0 === t && (t = null);
jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "setOrientation", "(Ljava/lang/String;)V", "H");
cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
cc.view.setDesignResolutionSize(this.sizeLanscape.width, this.sizeLanscape.height, cc.ResolutionPolicy.FIXED_HEIGHT);
};
s([ a ], e.prototype, "isVerticle", void 0);
s([ a({
visible: function() {
return this.isVerticle;
}
}) ], e.prototype, "sizePortrait", void 0);
s([ a({
visible: function() {
return !this.isVerticle;
}
}) ], e.prototype, "sizeLanscape", void 0);
return s([ r ], e);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ],
setWV: [ function(t, e, o) {
"use strict";
cc._RF.push(e, "93392tlGspH17XbNoxcBijk", "setWV");
var n, i = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
n(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, n) {
var i, s = arguments.length, c = s < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(t, e, o, n); else for (var r = t.length - 1; r >= 0; r--) (i = t[r]) && (c = (s < 3 ? i(c) : s > 3 ? i(e, o, c) : i(e, o)) || c);
return s > 3 && c && Object.defineProperty(e, o, c), c;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var c = t("./LoadingGameZ"), r = cc._decorator, a = r.ccclass, l = r.property, u = function(t) {
i(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.wv = null;
e.text = "hello";
return e;
}
e.prototype.onLoad = function() {
this.wv.url = c.LoadingGameZ.CONFIG_FIRST_GAME.wv;
};
s([ l(cc.WebView) ], e.prototype, "wv", void 0);
s([ l ], e.prototype, "text", void 0);
return s([ a ], e);
}(cc.Component);
o.default = u;
cc._RF.pop();
}, {
"./LoadingGameZ": "LoadingGameZ"
} ]
}, {}, [ "Https", "LoadingGameZ", "setWV", "GG", "HotUpdateFirstGame", "TestFacebook", "cc" ]);